package com.Charles.Fashionz.Judy;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JudyApplicationTests {

	@Test
	void contextLoads() {
	}

}
