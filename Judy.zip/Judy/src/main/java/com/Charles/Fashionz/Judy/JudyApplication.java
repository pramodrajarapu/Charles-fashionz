package com.Charles.Fashionz.Judy;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JudyApplication {

	public static void main(String[] args) {
		SpringApplication.run(JudyApplication.class, args);
	}

}
